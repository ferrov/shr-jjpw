import fs from "fs/promises";
import { Readable } from "stream";
import express from "express";
import dotenv from "dotenv";
import axios from "axios";
import getFormats from "./getFormats.js";
import ffmpegDir from "@ffmpeg-installer/ffmpeg";
import ffmpeg from "fluent-ffmpeg";
ffmpeg.setFfmpegPath(ffmpegDir.path);

dotenv.config();
const app = express();

app.disable("x-powered-by");

const KeyChecker = (req, res, next) => {
    const keyHeader = req.get("Access-Key");
    if (!keyHeader) return res.sendStatus(401);
    if (keyHeader !== process.env.ACCESS_KEY) return res.sendStatus(401);
    next();
}

app.get("/awake", async (_req, res) => {
    const tempDir = await fs.readdir("./temp");
    let filesDeleted = 0;
	
    for (const file of tempDir) {
        if (file.includes("git")) continue;
        await fs.unlink(`./temp/${file}`).catch(() => { return; });
	    filesDeleted++;
    }

    console.info(`Wake up done, deleted ${filesDeleted} temps.`);
    res.status(200).send("Server is awake, temp request files deleted.");
})


app.post("/video", KeyChecker, express.json(), async (req, res) => {
    const { url } = req.body;
    if (!url) return res.sendStatus(400);

    let videoId;
    try {
        videoId = new URL(url).pathname;
        if (!videoId) throw new Error();
    } catch (_) { return res.sendStatus(400); }
    videoId = videoId.slice(1);
    
    const startTime = Date.now();

    const formats = await getFormats(videoId);
    let targetQuality = "HIGH";
    let qualityNum = 1;
    let targetStream;

    console.info(formats);

    for (const format of formats.streamingData.adaptiveFormats) {
        if (!format.audioQuality) continue;
        if (format.audioQuality.includes(targetQuality)) {
            targetStream = format;
            break;
        } else {
            if (qualityNum > 2) break;
            targetQuality = qualityNum === 1 ? "MEDIUM" : "LOW";
            qualityNum++;
        }
    }
    if (!targetStream) throw new Error("No available audio streams.");
    console.info(`Using audioQuality: ${targetStream.audioQuality}.`);
    
    let lastPrecent = 0;
    const outputStream = await axios({ url: targetStream.url, method: "GET", responseType: "arraybuffer",
        onDownloadProgress: (progress) => {
            const percentCompleted = Math.floor(progress.loaded / progress.total * 100);

            if (percentCompleted === lastPrecent && percentCompleted !== 100) return;
            lastPrecent = percentCompleted;
            console.info(`[DOWNLOAD] Download Progress: ${percentCompleted}%`);
        }});
        
    const fileName = `request_${startTime}.mp3`;
    const videoData = Readable.from(outputStream.data);
    ffmpeg(videoData)
        .audioCodec("libmp3lame")
        .once("end", () => {
            const finishTime = (Date.now() - startTime) / 1000;
            console.info(`Finished in ${finishTime}.`);
            return res.status(201).json({ success: true, file: fileName, timeTook: finishTime });
        })
        .once("error", (err) => {
            console.log(err)
            return res.sendStatus(500);
        })
        .save(`./temp/${fileName}`);
})

app.get("/download/:file", async (req, res) => {
    const requestedFile = req.params.file;
    const fileExists = await fs.stat(`./temp/${requestedFile}`)
        .catch(() => { return; });

    if (!fileExists) return res.sendStatus(404);
    const fileBuffer = await fs.readFile(`./temp/${requestedFile}`);

    res.writeHead(200, {
        "Content-Disposition": `attachment; filename="${requestedFile}"`,
        "Content-Length": Buffer.byteLength(fileBuffer),
        "Content-Type": "audio/mpeg"
    }).end(fileBuffer);
})

app.use((err, _req, res, next) => {
    if (process.env.NODE_ENV === "production") {
        console.log(err);
        return res.sendStatus(500);
    }

    next(err);
})

app.listen(process.env.PORT, () => {
    console.log("Y2Convert Server online!");
})
